#!/bin/bash
# Jenkins中项目的workspace路径：请修改
readonly project_workspace="${JENKINS_HOME}/workspace/new-blackcat"
# JiraTools的目录：请修改，默认放到项目根目录
readonly jiratools_path="${project_workspace}/JiraTools"

echo "-----The path of the project workspace is ${project_workspace}"
echo "-----The path of the JiraTools is ${jiratools_path}"

# 复制代码清单文件到日志目录
echo "-----Create the code-list-deploy-${BUILD_NUMBER}.txt file to log"
yes | cp -rf "${jiratools_path}/deploy/code-list-update.txt" "${jiratools_path}/deploy/deloy-logs/code-list-deploy-${BUILD_NUMBER}.txt"
echo "" > ${jiratools_path}/deploy/code-list-update.txt

# 复制脚本清单文件到日志目录
echo "-----Create the sql-file-list-deploy-${BUILD_NUMBER}.txt file to log"
yes | cp -rf "${jiratools_path}/deploy/sql-file-list-update.txt" "${jiratools_path}/deploy/deloy-logs/sql-file-list-deploy-${BUILD_NUMBER}.txt"
echo "" > ${jiratools_path}/deploy/sql-file-list-update.txt

# 发布war到tomcat7
echo "Start to redepl the war..."
cd ${project_workspace}/blackcat-web
mvn -Dmaven.test.skip=true tomcat7:redeploy

echo "Deploy complete!"
exit 0