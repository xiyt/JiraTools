#!/bin/bash
# Jenkins中项目的workspace路径：请修改
readonly project_workspace="${JENKINS_HOME}/workspace/new-blackcat"
# JiraTools的目录：请修改，默认放到项目根目录
readonly jiratools_path="${project_workspace}/JiraTools"


echo "-----The path of the project workspace is ${project_workspace}"
echo "-----The path of the JiraTools is ${jiratools_path}"

# 获取当前时间
current_date=$(date "+%Y%m%d%H%M")
echo "-----current date is ${current_date}"

# 从文件获取上次代码的更新时间
last_update_date=$(tail -1 ${jiratools_path}/deploy/deploy.info)
if [ "$last_update_date" = "" ]
	then last_update_date="198501290000"
fi
echo "-----The last update date is ${last_update_date}"

# 调用Java将从上次发布时间开始到现在，
# jira状态从from变为to的单子关联的代码保持成代码清单文件
echo "-----The jira issue key is ${JIRA_ISSUE_KEY}"
result=$(java -jar ${jiratools_path}/JiraTools.jar "$JIRA_ISSUE_KEY" $last_update_date)

echo "-----The result of the JiraTools is ${result}"
if [ "$result" = "success" ]
	then
		code_list_file="${jiratools_path}/deploy/code-list-update.txt"
		sql_file_list_file="${jiratools_path}/deploy/sql-file-list-update.txt"
	# 更新代码清单
	echo "-----Start to update the code list..."
	for line in $(cat $code_list_file)
	do
		svn update ${project_workspace}/$line
	done

	# 更新sql文件清单
	echo "-----Start to update the sql file list..."
	for line in $(cat $sql_file_list_file)
	do
		svn update ${project_workspace}/$line
	done

	# 执行sql文件清单
	echo "-----Start to execute the sql file..."
	for line in $(cat $sql_file_list_file)
	do
		mysql --defaults-file=/app/mgr/mysql/mysql.cnf -ujenkins -pjenkins123 < "${project_workspace}/${line}"
		if [ $? != 0 ]
		then 
			exit 1
		fi
	done

	# 代码的最后更新时间
	if [ "$JIRA_ISSUE_KEY" == "" ]
		then 
			echo "-----Start to write the new update date to file..."
			echo $current_date >> ${jiratools_path}/deploy/deploy.info 
	fi

	echo "Update source complete!"
else
	echo $result
fi
exit 0